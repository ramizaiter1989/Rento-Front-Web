import{d as e}from"./index-DbvXYXc0.js";const o=[["path",{d:"M5 12h14",key:"1ays0h"}],["path",{d:"M12 5v14",key:"s699le"}]],t=e("plus",o);export{t as P};
