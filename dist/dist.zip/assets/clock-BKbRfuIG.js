import{d as c}from"./index-DbvXYXc0.js";const o=[["circle",{cx:"12",cy:"12",r:"10",key:"1mglay"}],["polyline",{points:"12 6 12 12 16 14",key:"68esgv"}]],i=c("clock",o);export{i as C};
