import{d as e}from"./index-DbvXYXc0.js";const o=[["path",{d:"m3 11 18-5v12L3 14v-3z",key:"n962bs"}],["path",{d:"M11.6 16.8a3 3 0 1 1-5.8-1.6",key:"1yl0tm"}]],t=e("megaphone",o);export{t as M};
