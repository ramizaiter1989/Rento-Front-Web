import{d as c}from"./index-DbvXYXc0.js";const e=[["circle",{cx:"12",cy:"12",r:"10",key:"1mglay"}]],r=c("circle",e);export{r as C};
