import{d as e}from"./index-DbvXYXc0.js";const c=[["path",{d:"M7.9 20A9 9 0 1 0 4 16.1L2 22Z",key:"vv11sd"}]],o=e("message-circle",c);export{o as M};
